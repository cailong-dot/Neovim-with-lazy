return{
  { 
    'echasnovski/mini.nvim', 
    version = '*',
    config = function()
      
    end
  },
}
