return {
	"phaazon/hop.nvim",
	branch = "v2",
	-- event = { CmdlineEnter },
	config = function()
		require("hop").setup()
	end,
}
